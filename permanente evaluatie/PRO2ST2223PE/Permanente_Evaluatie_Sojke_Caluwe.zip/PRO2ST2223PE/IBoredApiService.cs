﻿namespace PRO2ST2223PE
{
    public interface IBoredApiService
    {
        public BoredResponse GetBoredResponse();
    }
}