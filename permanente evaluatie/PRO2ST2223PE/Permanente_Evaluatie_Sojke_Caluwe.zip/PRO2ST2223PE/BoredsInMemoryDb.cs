﻿using System.Collections.Generic;

namespace PRO2ST2223PE;

public class BoredInMemoryDb
{
    public static List<BoredResponse> boredResponses = new List<BoredResponse>();
}
